// jiedian/listDetail/listDetail.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    ld:{
      bg:"http://bpic.588ku.com/back_pic/04/87/68/3758ee2816d855f.jpg"
    },
    card:{}
  },
  navfn(){
    console.log(this,this.data.card);
    //经纬度类型必须为Number
    var latitude=this.data.card.latitude,longitude=this.data.card.longitude;
    //打开地图
    wx.openLocation({
      latitude: Number(latitude),
      longitude: Number(longitude)
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that=this;
    // 获取云开发数据库的索引
    var db=wx.cloud.database();
    // 获取集合jdshop
    db.collection("jdshop").where({
      _openid:"orOek5JunLGBMybLHrTmsU5kGjTY"
    }).get({
      success:res=>{
        console.log(res,"获取集合成功");
        that.setData({
          card:res.data[0]
        })
      }
    })
    //从集合jdshop获取数据拿id做条件
    db.collection("jdshop").doc("XDB4bMDR1TiNV4xF").get({success:res=>{
      console.log(res,"jdshop");
    }});
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})