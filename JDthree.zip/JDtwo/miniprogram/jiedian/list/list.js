// jiedian/list/list.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    shload:true,
    maptab:{
      img:"/images/jiedian/map.png",
      text:"切换为地图视图",
      href:"/jiedian/index/index"
    },
    listdata:[{
      leftimg:"http://songshudiandian.com/img/jg3%20(3).png",
      topic:"辉煌大厦",
      time:"周一至周日09:00-20:00",
      address:"东莞市大朗镇辉煌大厦385号B610",
      iphone:"有",
      android:"有",
      dataline:"有",
      status:"可归还"
    }]
  },
  digui() {
    //获取设备信息
    var system = wx.getSystemInfoSync();
    var query = wx.createSelectorQuery();
    query.select("#lw-load").boundingClientRect().exec(function (res) {
      console.log(res, "什么猫腻？");
      var top = res[0].top;
      if (system.windowHeight > top) {
        wx.that.lazyload();
      }
    });
  },
  lazyload(ev){
    var db=wx.cloud.database();
    var that = this;
    var jointobj = that.data.listdata;
   
    if (that.data.shload) {
      //获取集合jdshop的数据
      db.collection("jdshop").where({ _openid:"orOek5JunLGBMybLHrTmsU5kGjTY"}).get({
        success:res=>{
          console.log(res,"师弟");
          var joint = that.data.listdata;
          if (res.data ? res.data.length > 0 : 0) {

            joint.push(res.data[0]);
            that.setData({ listdata: joint, shload: true, size: joint.length });

            if (joint.length > 30) {
              that.setData({ shload: false });
            }
            //递归函数
            that.digui();
          } else {
            that.setData({ shload: false });
          }
        },
        fail:err=>{
          wx.showToast({
            icon: 'none',
            title: '查询记录失败'
          })
          console.error('[数据库] [查询记录] 失败：', err)
          
        }
      })
      //拉到底时触发请求
      /*
      wx.request({
        url: "https://www.zhipin.com/common/data/city.json",
        method:"GET",
        dataType:"json",
        success: function (res) {
          var joint = that.data.listdata;
          if (res.data.data.hotCityList ? res.data.data.hotCityList.length > 0 : 0) {
            
            joint.push(joint[0]);
            that.setData({ listdata: joint, shload: true, size: joint.length });

            if (joint.length > 30) {
              that.setData({ shload: false });
            }
            //递归函数
            wx.that.digui();
          } else {
            that.setData({ shload: false });
          }
        },
        fail: function (res) {
          that.setData({ shload: false });
          console.log(res, "错误");
        }
      });
      */
      that.setData({ listdata: jointobj });
    }
  },
  getshopfn(){
    
    // this.onAdd();
    wx.navigateTo({
      url: '/jiedian/listDetail/listDetail',
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {  

    wx.that = this;
    //获取屏幕高度
    this.setData({screenHeight:wx.getSystemInfoSync().windowHeight});
    //启动懒加载函数
    this.lazyload();
  },
  onAdd:function(){
    //获取云开发的数据库
    const db=wx.cloud.database();
    //向集合jdshop增加子集
    db.collection("jdshop").add({
      data:wx.that.data.listdata[0],
      success:res=>{
        wx.showToast({
          title: '新增记录成功',
        })
        console.log(res,'[数据库] [新增记录] 成功，记录 _id: ', res._id)
      },
      fail:err=>{
        wx.showToast({
          icon: 'none',
          title: '新增记录失败'
        })
        console.error('[数据库] [新增记录] 失败：', err)
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})