// miniprogram/jiedian/index/index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    poistatus:false,
    userimg:"/images/jiedian/user.png",
    adpic:"https://www.kaitao.cn/data/upload/ueditor/20161116/582bf0733206a.png",
    showlocation:true,
    showcompass:true,
    searchcontent: { name:"搜索位置查看附近街电"},
    listdata: [{
      leftimg: "http://songshudiandian.com/img/jg3%20(3).png",
      topic: "辉煌大厦",
      time: "周一至周日09:00-20:00",
      address: "东莞市大朗镇辉煌大厦385号B610",
      iphone: "有",
      android: "有",
      dataline: "有",
      status: "可归还"
    }]
  },
  getshopfn() {
    // this.onAdd();
    wx.navigateTo({
      url: '/jiedian/listDetail/listDetail',
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.that=this;
    //指引地图变量
    this.mapCtx = wx.createMapContext('jdMap');
    //获取自身地理
    wx.getLocation({
      success: function(res) {
        console.log(res,"获取自身成功");
        if (!isNaN(res.longitude)&&!isNaN(res.latitude)){
          wx.that.setData({
            longitude:res.longitude,
            latitude:res.latitude,
            markers: [
              {
                id: 0,
                latitude: res.latitude,
                longitude: res.longitude,
                iconPath: "/images/jiedian/location.png",
                width: 24,
                height: 24,
                zIndex: 999
              }
            ]
          })
        }
      },
    })
    //获取用户数据
    wx.getUserInfo({
      success:function(res){
        console.log(res,"获取微信个人数据");
        if(res.userInfo){
          wx.that.setData({
            userimg:res.userInfo.avatarUrl
          })
        }
      }
    })
  },
  userfn() {
    //跳转个人中心
    wx.navigateTo({
      url: '/jiedian/user/user',
    })
  },
  searchfn(){
    // 打开地图
    /*wx.getLocation({
      success: function(res) {
        console.log(res,"获取自身位置成功");
        wx.openLocation({
          latitude: res.latitude,
          longitude: res.longitude,
          success:function(call){
            console.log(call,"打开自身位置");
          }
        })
      },
    })
    */
    wx.chooseLocation({
      success: (res)=>{
        console.log(res,"选择地址成功");
        if (!isNaN(res.longitude) && !isNaN(res.latitude)){
          this.mapCtx.translateMarker({
            markerId: 0,
            destination: {
              latitude: res.latitude,
              longitude: res.longitude
            },
            duration: 100
          })
          this.setData({
            latitude:res.latitude,
            longitude:res.longitude,
            searchcontent:res
          })
        }
      },
    })
  },
  listfn(){
    //跳转列表页面
    wx.navigateTo({
      url: '/jiedian/list/list',
    })
  },
  moveToLocation: function () {
    //将中心坐标移到自身位置
    this.mapCtx.moveToLocation();
  },
  regionchangeFn: function (ev) {
    this.mapCtx.getCenterLocation({
      success: (res) => {
        
        if (ev.type == "end") {
          //关闭卡片，打开底部导航
          this.setData({ poistatus: false });
          //translateMarker是移动marker
          this.mapCtx.translateMarker({
            markerId: 0,
            destination: {
              latitude: res.latitude,
              longitude: res.longitude
            },
            duration: 100,
            animationEnd: () => {
              var markers = wx.that.data.markers;
              markers[0].latitude = res.latitude;
              markers[0].longitude = res.longitude;
              //删除makers子集从下标1开始后的所有子集
              markers.splice(1,);
              var pic=["bank.png","dianpu.png","food.png","ktv.png"];
              for(let pi=0;pi<20;pi++){
                //设置新添加的markers子集的id
                var idItem = markers.length;
                //仿地标
                //自己位置的周围
                //自身地标周围的随机纬度
                var latitude = res.latitude + Math.pow(-1, Math.round(Math.random())) * 0.015 * Math.random().toFixed(5);
                //自身地标周围的随机经度
                var longitude = res.longitude + Math.pow(-1, Math.round(Math.random())) * 0.015 * Math.random().toFixed(5);
                //随机地标
                var mItem = {
                  id: idItem,
                  latitude: latitude,
                  longitude: longitude,
                  iconPath: "/images/jiedian/"+pic[Math.floor(Math.random()*pic.length)],
                  width: 30,
                  height: 30,
                  zIndex: 999
                }
                markers.push(mItem);
              }
              //更新数据
              wx.that.setData({
                markers: markers
              });
            }
            ,
            fail: function (err) {
              console.log(err, "怎么回事？");
            }
          })


        }

      },
      fail: function (err) {
        console.log("犯了啥错？", err);
      }
    })

  },
  markerfn:function(res){
    console.log(res,"能获取到markers的id");
    //显示卡片，关闭底部导航
    this.setData({poistatus:true});
    console.log(this.data.poistatus);
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})