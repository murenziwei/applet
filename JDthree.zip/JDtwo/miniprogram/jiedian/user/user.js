// jiedian/user/user.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    user:{
      avatarUrl:"/images/jiedian/user.png",
      nickName:"未授权登录"
    },
    grade:{
      leftimg:"/images/jiedian/Vue.png"
    }
  },
  // 关于“更多”的方法
  manyfn(){
    wx.showActionSheet({
      itemList:["常见问题","关于我们"],
      success:res=>{
        console.log(res,"操作菜单成功");
      }
    })
  },
  // 进入个人信息的方法
  userdatafn(){
    wx.navigateTo({
      url: '/jiedian/userdata/userdata',
    })
  },
  // 进入vip服务的方法
  gradefn(){
    wx.navigateTo({
      url: '/jiedian/grade/grade',
    })
  },
  // 进入我的订单的方法
  orderfn(){
    wx.navigateTo({
      url: '/jiedian/myorder/myorder',
    })
  },
  // 进入我的钱包的方法
  moneyfn() {
    wx.navigateTo({
      url: '/jiedian/mymoney/mymoney',
    })
  },
  // 进入我的优惠券的方法
  uanmefn() {
    wx.navigateTo({
      url: '/jiedian/uanme/uanme',
    })
  },
  // 下载app的方法
  appfn(){
    wx.showModal({
      showCancel: false, content: "下载app弹框未做", success: function (res) {
        console.log("ad广告需开通广告主");
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    //获取屏幕高度
    var sch=wx.getSystemInfoSync().screenHeight;
    this.setData({sch:sch});
    //获取微信用户信息
    wx.getUserInfo({
      success:res=>{
        this.setData({
          user:res.userInfo
        })
        console.log(res,"用户信息");
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})