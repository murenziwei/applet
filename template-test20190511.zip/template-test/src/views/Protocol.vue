<template>
    <div class="protocol">
      <main class="p-main">
        <p class="pm-title">用户服务协议</p>
        <div class="pm-logo">
          <p class="pl-title pl-text">版本更新日期：2019-05-10</p>
          <p class="pl-blank pl-text">版本号：2019v3</p>
        </div>
        <div class="pl-content">
          欢迎您与各我方平台经营者（详见定义条款）共同签署本
          《用户服务协议》（下称“本协议”）并使用我方平台服务！

          各条款标题仅为帮助您理解该条款表达的主旨之用，不影
          响或限制本协议条款的含义或解释。为维护您自身权益，建议
          您仔细阅读各条款具体表述。

          【审慎阅读】 您在申请注册流程中点击同意本协议之前，
          应当认真阅读本协议。 请您务必审慎阅读、充分理解各条款
          内容，特别是免除或者限制责任的条款、法律适用和争议解
          决条款。免除或者限制责任的条款将以粗体下划线标识，您
          应重点阅读。 如您对协议有任何疑问，可向我方平台客服咨
          询。

          【签约动作】 当您按照注册页面提示填写信息、阅读并
          同意本协议且完成全部注册程序后，即表示您已充分阅读、
          理解并接受本协议的全部内容，并与我方平台网站达成一致，
          成为优酷网或我方平台“用户”。 阅读本协议的过程中，如果
          您不同意本协议或其中任何条款约定，您应立即停止注册程序。

          如果您未申请注册流程，您仍可浏览网站内容，但不能发表评
          论、弹幕或观看付费内容。
        </div>
      </main>
    </div>
</template>

<script>
    export default {
        name: 'protocol',
        data: function () {
            return {}
        }
    }
</script>

<style>
  body,html{font-size:unset !important;}

  body{margin:0;background:#141732;}
</style>
<style scoped>
  .protocol{
    position:absolute;
    top:0;
    right:0;
    left:0;
    right:0;
    width:100%;
    height:100%;
  }
  .p-main{
    padding:0 1rem;
    width:97%;
    box-sizing: border-box;
    background-color:#1c213e;
    border-radius: 5px;
    text-align: left;
    margin:0.5rem auto;
    border: 1px solid #393e6b;
  }

  .pm-title{
    font-size:0.9rem;
    color:#fff;
    margin:0;
    height:3rem;
    line-height:3rem;
  }
  .pl-text{
    text-align: right;
    font-size:0.4rem;
    color:#616478;
    margin:0;
    margin-bottom:0.5rem;
  }

  .pl-content{
    font-size:0.6rem;
    color:#fff;
    opacity:0.7;
    padding-bottom:2rem;
  }
</style>
