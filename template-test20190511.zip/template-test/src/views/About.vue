<template>
  <div class="about">
    <ul class="h-ul">
        <li class="h-list">
          <div class="h-list-nav">
            <div class="h-l-text hl-col a-text">2019-05-09 12:23 冻结</div>
            <div class="a-text a-fail">冻结中</div>
          </div>
          <div class="h-list-nav">
            <div class="h-l-text hl-col">
              <span class="ar-text">200 PDC</span>
              <span class="ar-info h-l-time">解冻费用</span>
            </div>
            <div class="h-l-time hl-col">
              <div class="ar-btn ab-success" @click.stop="_openplug">立即解冻</div>
            </div>
          </div>
        </li>
        <li class="h-list">
          <div class="h-list-nav">
            <div class="h-l-text hl-col a-text">2019-05-09 12:23 冻结</div>
            <div class="a-text a-success">已解冻</div>
          </div>
          <div class="h-list-nav">
            <div class="h-l-text hl-col">
              <span class="ar-text">200 PDC</span>
              <span class="ar-info h-l-time">解冻费用</span>
            </div>
            <div class="h-l-time hl-col">
              <div class="h-l-text hl-col a-text">2019-05-09 12:23 解冻</div>
            </div>
          </div>
        </li>
    </ul>
<!--冻结弹窗-->
    <Unfreeze :msg="2000" :show="show" @controlfn="_controlfn"></Unfreeze>
  </div>
</template>

<script>
  import Unfreeze from '@/components/Unfreeze.vue';
  export default {
    name: 'about',
    data(){
      return {
        show:false
      }
    },
    methods:{
      _controlfn($even){
        this.show=$even.show;
      },
      _openplug(){
        this.show=!this.show;
      }
    },
    components:{
      Unfreeze
    }
  }
</script>

<style>
  body,html{font-size:unset !important;}
  body{margin:0;background:#141732;}
</style>
<style scoped>
  .ar-text{
    font-size:1rem;
    color:#fff;
  }
  .ar-btn{
    height: 1.7rem;
    background-color: #1c213e;
    border-radius: 0.2rem;
    border: solid 1px #393e6b;
    font-family: PingFangSC-Regular;
    font-size: 0.7rem;
    font-weight: normal;
    font-stretch: normal;
    line-height: 1.7rem;
    letter-spacing: 0rem;
    padding:0 1rem;
    text-align:center;
    transition:all .5s;
    user-select:none;
  }
  .ab-success{
    background-color:#4075f5;

    background-blend-mode: normal,
    normal;
    border-radius: 0.2rem;
    border: solid 0rem #345cca;
    color:#fff;

  }
  .ab-success:active{
    background-color:transparent;
    opacity: 0.7;

  }

  .a-text{
    font-size:0.8rem;
    color:#fff;
    opacity:0.7;
  }

  .a-text.a-fail{
    color:#3666bd;
  }
  .a-text.a-success{
    color:#3deed9;
  }
  .h-ul{
    margin:0;
    padding:0;
  }
  .h-l-text{
    color:#fff;
    font-size:0.9rem;
    flex:1;
    text-align: left;
  }
  .h-l-time{
    color:#616478;
    font-size:0.5rem;
    padding-left:0.5rem;
  }
  .h-list{

    width:97%;
    box-sizing: border-box;
    background-color:#1c213e;
    border-radius: 3px;
    margin:0.5rem auto;

    border: 1px solid #393e6b;
  }
  .h-list-nav{
    padding:1rem 0.5rem;
    width:100%;
    box-sizing: border-box;
    display:flex;
    align-items:center;
    text-decoration: none;
  }

</style>
