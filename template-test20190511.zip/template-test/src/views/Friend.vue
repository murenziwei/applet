<template>
    <div class="friend">
      <header>
        <div class="f-header">
          <div class="fh-item">
            <div class="f-i-val">323</div>
            <div class="f-i-type">普通好友</div>
          </div>
          <div class="fh-item">
            <div class="f-i-val">323</div>
            <div class="f-i-type">VIP好友</div>
          </div>
          <div class="fh-item">
            <div class="f-i-val">323</div>
            <div class="f-i-type">我的团队</div>
          </div>
        </div>
      </header>
      <main>
        <div class="f-main">
          <p class="fm-topic">好友列表</p>
          <table class="fm-table">
            <thead class="fm-thead">
               <tr class="f-th-tr">
                 <th>
                   昵称
                 </th>
                 <th>手机号</th>
                 <th>是否vip</th>
                 <th>进入时间</th>
               </tr>
            </thead>
            <tbody class="fm-tbody">
              <tr class="f-tb-tr">
                <td class="fbt-td">
                  <div>
                    <span class="f-td-text">木人子韦</span>
                  </div>
                </td>
                <td>
                  <div>
                    <span class="f-td-text">13825000114</span>
                  </div>
                </td>
                <td>
                  <div>
                    <span class="f-td-text text-is">是</span>
                  </div>
                </td>
                <td>
                  <div>
                    <span class="f-td-text">2109-02-03 11:11:11</span>
                  </div>
                </td>
              </tr>

              <tr class="f-tb-tr active">
                <td class="fbt-td">
                  <div>
                    <span class="f-td-text">木人子韦</span>
                  </div>
                </td>
                <td>
                  <div>
                    <span class="f-td-text">13825000114</span>
                  </div>
                </td>
                <td>
                  <div>
                    <span class="f-td-text text-is">是</span>
                  </div>
                </td>
                <td>
                  <div>
                    <span class="f-td-text">2109-02-03 11:11:11</span>
                  </div>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </main>
    </div>
</template>

<script>
    export default {
        name: 'friend',
        data: function () {
            return {}
        }
    }
</script>

<style>
  body,html{
    font-size:unset!important;
  }
  body{margin:0;background:#141732;}
</style>
<style scoped>
  .f-td-text{
    font-size:0.8rem;
    color:#fff;
    text-align:left;
  }
  .f-td-text.text-is{
    color:#3deed9;
  }
  .f-main{
    width:95%;
    margin:auto;
  }
  .fm-table{
    width:100%;
    border-radius:10px;
    border-spacing:0;
    overflow:hidden;
  }
  .fm-tbody{
    width:100%;
  }
  .fm-tbody td,.fm-thead th{
    padding:1rem 0;
  }
  .fm-tbody tr{
    background-color:rgba(28,33,62,1);
  }
  tr.active{
    background-color:rgba(28,33,62,0.5);
  }
  .fm-thead{
    background-color:#090d2d;
  }
  .fm-thead th{
    color:#fff;
    font-size:0.8rem;
    text-align:center;
    opacity:0.5;
  }
  .fm-topic{
    font-size:1.2rem;
    color:#fff;
    line-height:3rem;
    text-align:left;
    width:95%;
    margin:auto;
  }
  .f-i-val{
    font-size:1.5rem;
    color:#fff;
  }
  .f-i-type{
    font-size:0.9rem;
    color:#fff;
    opacity:0.5;
  }
  .fh-item{
    text-align:center;
    line-height:2rem;
  }
  .f-header{
    width:100%;
    box-sizing: border-box;
    display:flex;
    align-items:center;
    height:8rem;
    justify-content:space-around;
  }
</style>
