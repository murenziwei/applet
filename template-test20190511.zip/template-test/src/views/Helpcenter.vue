<template>
    <div class="helpcenter">
      <ul class="h-ul">
        <template v-for="item in helpdata">

          <li class="h-list">
            <router-link to="/helpdetail" class="h-list-nav">
              <div class="h-l-text hl-col">排单币如何转化？</div>
              <div class="h-l-time hl-col">15:22</div>
            </router-link>
          </li>
        </template>
      </ul>
    </div>
</template>

<script>
    export default {
        name: 'helpcenter',
        data: function () {
            return {
              helpdata:[1,2,3]
            }
        }
    }
</script>

<style>
  body,html{font-size:unset !important;}
  body{margin:0;background:#141732;}
</style>
<style scoped>

  .helpcenter{
    position:absolute;
    top:0;
    right:0;
    left:0;
    right:0;
    width:100%;
    height:100%;
  }
  .h-ul{
    margin:0;
    padding:0;
  }
  .h-l-text{
    color:#fff;
    font-size:0.9rem;
    flex:1;
    text-align: left;
  }
  .h-l-time{
    color:#616478;
    font-size:0.5rem;
  }
  .h-list{

    width:97%;
    box-sizing: border-box;
    background-color:#1c213e;
    border-radius: 3px;
    margin:0.5rem auto;
    display:flex;
    align-items:center;
    margin-bottom:0.5rem;
    border: 1px solid #393e6b;
  }
  .h-list-nav{
    padding:1rem 0.5rem;
    width:100%;

    display:flex;
    align-items:center;
    text-decoration: none;
  }
  .h-list-nav:active{
    opacity:0.7;
  }

</style>
