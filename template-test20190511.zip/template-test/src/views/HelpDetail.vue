<template>
  <div class="protocol">
    <main class="p-main">
      <p class="pm-title">美国证券交易委员会：多数评论支持比特币ETF获得
        批准</p>
      <div class="pm-logo">
        <p class="pl-title pl-text">2019-05-10 18:30:00</p>
        <hr class="pl-hr" />
      </div>
      <div class="pl-content">
        据CoinDesk消息，美国证券交易委员会（SEC）今年夏
        天就比特币ETF的相关话题征求了意见，该评论期现已结束，
        结果显示多数评论是积极的。提议变更规则的支持者认为，比
        特币ETF实际上使加密市场成为投资者更安全、更值得信赖的
        交易场所。而如果比特币ETF获得批准，将允许Cboe和区块链
        技术公司SolidX推出受监管的比特币ETF。
      </div>
    </main>
  </div>
</template>

<script>
  export default {
    name: 'helpdetail',
    data: function () {
      return {}
    }
  }
</script>

<style>
  body,html{font-size:unset !important;}
  body{margin:0;background:#141732;}
</style>
<style scoped>
  .protocol{
    position:absolute;
    top:0;
    right:0;
    left:0;
    right:0;
    width:100%;
    height:100%;
  }
  .p-main{
    padding:0 1rem;
    width:97%;
    box-sizing: border-box;
    background-color:#1c213e;
    border-radius: 5px;
    text-align: left;
    margin:0.5rem auto;
    border: 1px solid #393e6b;
  }

  .pm-title{
    font-size:0.9rem;
    color:#fff;
    margin:0;

    line-height:1.5rem;
    padding-top:1rem;
    padding-bottom:1rem;
  }
  .pl-text{
    text-align: left;
    font-size:0.4rem;
    color:#616478;
    margin:0;
    margin-bottom:0.5rem;
  }
  .pl-hr{
    height:1px;
    background-color:#616478;
    width:100%;
    border:none;
  }

  .pl-content{
    font-size:0.6rem;
    color:#fff;
    opacity:0.7;
    padding-bottom:2rem;
  }
</style>
