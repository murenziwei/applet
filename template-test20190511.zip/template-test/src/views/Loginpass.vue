<template>
  <div class="login">
    <form action="" class="form-login">
      <div class="f-l-item">
        <div class="fli-row">
          <div class="lp-name">
            <span class="lp-text">手机号</span>
          </div>
          <div class="f-col">
            <input type="text" placeholder="请输入绑定手机号" class="fc-input" value="13825000114">
          </div>
        </div>
        <div class="fli-row">
          <div class="lp-name">
            <span class="lp-text">验证码</span>
          </div>
          <div class="f-col">
            <input type="text" placeholder="填写验证码" class="fc-input" >
          </div>
          <div class="f-get">
            <div class="fg-btn">获取</div>
          </div>
        </div>
        <div class="fli-row">
          <div class="lp-name">
            <span class="lp-text">新的登录密码</span>
          </div>
          <div class="f-col">
            <input type="password" placeholder="请输入新的登录密码" class="fc-input">
          </div>
        </div>
        <div class="fli-row">
          <div class="lp-name">
            <span class="lp-text">确认登录密码</span>
          </div>
          <div class="f-col">
            <input type="password" placeholder="确认新的登录密码" class="fc-input">
          </div>
        </div>
      </div>
      <div class="fli-btns">
        <button class="f-btn f-b-login">确认</button>
      </div>
    </form>
  </div>
</template>

<script>
  export default{
    name:'loginpass'
  }
</script>
<style>
  body,html{font-size:unset !important;}

  body{margin:0;background:#141732;}
</style>
<style scoped>
  .lp-name{
    padding-left:1rem;
  }
  .lp-text{
    color:#fff;
    font-size:0.9rem;
  }
  .login{
    box-sizing: border-box;
    padding-top:2rem;
    position:absolute;
    top:0;
    right:0;
    left:0;
    right:0;
    width:100%;
    height:100%;
    background-image: url(../assets/login-bg.png);
    background-size:22rem 18.5rem;
    background-position:center 4rem;
    background-repeat:no-repeat;
  }
  .form-login{
    width:90%;
    margin:auto;
  }
  .f-l-item{
    margin-bottom:1rem;
    border: 1px solid #393e6b;
  }
  .fli-row{
    display:flex;
    align-items:center;
    padding:1rem 0;
    background-color:rgba(28,33,62,1);
  }
  .fli-row:first-child{
    border-top-left-radius: 5px;
    border-top-right-radius: 5px;
  }
  .fli-row:last-child{
    border-bottom-left-radius: 5px;
    border-bottom-right-radius: 5px;
  }

  .f-btn{
    border:none;
    outline:none;
    margin:0;
  }
  .f-b-login{
    background-color:#4075f5 ;
    width:100%;
    font-size:1rem;
    color:#fff;
    background-blend-mode: normal,normal;
    border-radius:5px;
    border: solid 5px #4075f5;
    height:3rem;
  }
  .f-col{
    flex:1;
  }
  .fc-input{
    box-sizing: border-box;
    padding:0 1rem;
    width:100%;
    height: 1rem;
    font-family: SourceHanSansCN-Regular;
    font-size: 0.9rem;
    font-weight: normal;
    font-stretch: normal;
    letter-spacing: 0rem;
    color: #fff;
    background-color:transparent;
    border:none;
    outline:none;
    flex:1;
  }

  .fc-input::placeholder{
    font-family: SourceHanSansCN-Regular;
    font-size: 0.9rem;
    font-weight: normal;
    font-stretch: normal;
    letter-spacing: 0rem;
    color: #e9e9e9;
    opacity: 0.2;
  }
  .f-get{
    margin-right:1rem;
  }
  .fg-btn{
    height: 1.7rem;
    background-color: #1c213e;
    border-radius: 0.2rem;
    border: solid 1px #393e6b;
    font-family: PingFangSC-Regular;
    font-size: 0.8rem;
    font-weight: normal;
    font-stretch: normal;
    line-height: 1.7rem;
    letter-spacing: 0rem;
    color: #ffffff;
    padding:0 1rem;
  }



</style>
