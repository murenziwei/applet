<template>
  <div class="safety">
    <div class="home-content">
      <div class="f-l-item">
        <router-link class="fli-row" to="/loginpass">
          <div class="f-col f-text">
            修改登录密码
          </div>
          <div class="f-c-right">
            <div alt="" class="fc-img" />
          </div>
        </router-link>
        <router-link class="fli-row" to="/dealpass">
          <div class="f-col f-text">
            修改交易密码
          </div>
          <div class="f-c-right">
            <div alt="" class="fc-img" />
          </div>
        </router-link>
      </div>

    </div>
  </div>
</template>

<script>

  export default {
    name: 'safety'
  }
</script>

<style>
  body,html{font-size:unset !important;}

  body{margin:0;background:#141732;}
</style>
<style scoped>

  .home-content{
    width:95%;
    margin:auto;
    margin-top:1rem;
  }
  .f-l-item{
    margin-bottom:1rem;
    border: 1px solid #393e6b;
  }
  .fli-row{
    display:flex;
    align-items:center;
    padding:0.7rem 1rem;
    background-color:rgba(28,33,62,1);
    text-decoration:none;
    transition:all .3s;
  }
  .fli-row:active{
    opacity:0.6;
  }

  .fli-row:first-child{
    border-top-left-radius: 5px;
    border-top-right-radius: 5px;
  }
  .fli-row:last-child{
    border-bottom-left-radius: 5px;
    border-bottom-right-radius: 5px;
  }

  .f-col{
    flex:1;
  }

  .f-text{
    margin-right:1rem;
    font-family: PingFangSC-Regular;
    font-size: 0.8rem;
    font-weight: normal;
    font-stretch: normal;
    letter-spacing: 0rem;
    color: #ffffff;
    text-align:left;
  }


  .fc-img{
    width:0.8rem;
    height:1rem;
    background-image:url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAADICAYAAACtWK6eAAAMBElEQVR4Xu2dT6hvVRXHv/s9oswQDCWjIgcKNrBBDR6VVvog0/wHPgf6BqKQKAQ6KHTma6SDQifpRJ3o5L1BTyIkxJdZphFNmjQoKApKiiiQ0ERlxX6dW/fdd3/3nj97rbP3OZ/f9O691j6ftT7ss3+/3/2dJF4QgMBGAgk2EIDAZgIIQndAYA8CCEJ7QABB6AEIjCPADjKOG7NWQgBBVlJoLnMcAQQZx41ZKyGAICspNJc5jgCCjOPGrJUQQJCVFJrLHEcAQfbgZmaXSnojpfTXcXiZ1ToBBNlQQTP7pKRfSHpT0udSSn9rvdisfzgBBNmFmZl9rJPj492ffy/pypTSX4YjZkbLBBBkR/U6OV6RdPGOP/1R0ueRpOV2H752BNnGzMw+0u0cO+XYGoUkw3us6RkI0pWvkyPvHJfsU1Ekabrlhy0eQSSZ2QWSXushBzvJsP5qfvTqBTGz8yW9KumygdXMO8kXU0p/GjiP4Q0RWLUgnRwvS7p8ZM3+3B3ckWQkwNqnrVYQMztPUj5zjJVjq7ZIUnuXT1jfKgXp5HhJ0mcmsNs+FUkKgawtzOoEMbNzJf20oBzsJLV1dcH1rEqQTo5Tkg4VZLhzJ8mfuP/BKT5hgwmsTZAvS8q3Vp6v1yV9KaX0O88kxI4hsCpBMlIzu0HSSUkHHRHnb//mLziykzhCjgi9OkE6SW6RdBxJIlqs7RyrFARJ2m7ayNWvVpBgSfIn7r+NLCy5yhBYtSCBkvxd0heQpEzTRkZZvSDbJDkh6YAjfCRxhOsVGkE6smZ2u6RnkMSr1dqMiyDb6oYkbTax56oRZAfdQEnyh4m/8SwusacTQJBdGHaSPCvJk88/JV2BJNOb2DOCZwN4rts9tpndKekpJHFHXXUCBNmjPEhSde+GLA5B9sGMJCF9WG0SBOlRmk6Sp3sMnTIkn0muSin9ekoQ5pYlgCA9eZrZPZKe6Dl87LA3uh+CQJKxBAvPQ5ABQJFkAKyFDEWQgYVEkoHAGh+OICMKiCQjoDU6BUFGFi5QksMppV+NXCbTJhJAkAkAzew+SY9NCNFn6r+6d7eQpA+twmMQZCJQJJkIsPLpCFKgQEhSAGKlIRCkUGGQpBDIysIgSMGCmNkDkh4pGHK3UPlM8pWUUn5cAy9nAghSGHCQJG9Jyu9uIUnh+u0MhyAOgJHEAepMIRHECTySOIENDosgjsDN7JikhxxT5NDcbjkCRhBHuDm0mT0s6UHnNFmSa1NK+WlZvAoSQJCCMDeFCpLkbUnXIEnZgiJIWZ4boyFJEOjCaRCkMNC9wpnZo5Lud07JTlIQMIIUhNknFJL0oVTPGASZoRaBklyfUnpxhktcTEoEmamUQZK8I+k6JBlfZAQZz27yTDN7XNK9kwPtHQBJJgBGkAnwSkxFkhIU/WIgiB/b3pGRpDeq8IEIEo5894SBktycUnq+ksuufhkIUlGJgiR5V9JNSNKv8AjSj1PYKDPLvyh/l3NCJOkJGEF6goochiSRtPfOhSD11OKMlSBJHYVBkDrqsOsqAiW5NaX0XMUoZlsagsyGvl9iM8uPgjvab/ToUe9JOoIkZ/NDkNE9FTPRzHKN8uOpkSQG+RlZEGQG6ENTIslQYuXGI0g5lq6RkMQV78bgCDIP91FZO0lO5PPCqAD9J+UzydGU0vH+U5Y5EkEaq6uZHZCUG9dbEpN029olQZDGBMnLRZK4oiFIHOuimZCkKE7OIDE4Y7MgiT9vdhB/xq4ZOklOSrrRNZGUzyR3pJTyZzKreSHIAkptZgclfR9JyhcTQcoznSUikvhgRxAfrrNERZLy2BGkPNNZI3aS/FDSV50XsoozCYI4d9Ec4c3sfZJ+ECTJ3SmlJ+e4zoicCBJBeYYcgZLkq/v6UiVBkBmaNyolkkwnjSDTGVYdAUmmlQdBpvFrYnYnyY8kXR2w4EXdbiFIQMfUkMLM3i8p/2BchCTfSCl9r4brnroGBJlKsKH5SDK8WAgynFnTM5BkWPkQZBivRYzuJMkP1rki4IKavt1CkIAOqTGFmZ0j6QUk2bs6CFJj9watKViSb6aUvht0acXSIEgxlG0GQhJ2kDY7N3DVnSQvSToUkLapnYQdJKAjWkhhZudKOoUkZ1YLQVro3qA1IsnZoBEkqPlaSWNmF0l6PWi9V6WUfhKUa1QaBBmFbZmTgs8i30kpfat2kghSe4WC1hf8blYTcmT0CBLUgDWnCZbj2ymlYzXz2L42BGmlUk7rDJajqbd42UGcmq6VsMixf6XYQfZntMgRwV9YbG7n2Co6giyy/fe+qOCvvDcrB7dYyOFNoGk5EMS7PSqLz84xvCDcYg1n1uSM4B9uaH7n4AzSZJuPW3TwT/8sRg5uscb1W1OzkGNaubjFmsav6tnBcjT9v+ebCokgVbf4+MUhx3h222ciSBmOVUUJfARCvu5F7hwc0qtq6XKLCXyIzuLl4JBeri+riIQc5cvALVZ5prNERA4f7AjiwzU0auCjoFdxW8UhPbR9fZN1chyXdMQ30+noiz6Q78aPHSSgq7xSIIcX2f/HRRB/xi4ZguVY1ENxhhQEQYbQqmQscsQVAkHiWBfJZGa5ZieCzhyr3Tm2ioUgRdo2JkgnxzOSjgZkXL0cmTGCBHRaiRTIUYLi8BgIMpxZ+AzkCEf+v4QIMh/73pnN7Fluq3rjKjoQQYriLB/MzJ6SdFf5yGdF5MyxC2QECei8sSmC5DBJd6eUnhy7ziXPQ5BKqxsoxx0ppfzOGC92kDZ6ADnqqRM7SD21OL0S5KirIAhSUT3M7HFJ9zovKZ85uK3qCRlBeoLyHoYc3oTHxUeQcdyKzkKOojiLBkOQojiHB0OO4cwiZyBIJO0duczsUUn3Oy+BM8cEwAgyAd6UqYFy3JZSyv+Sy2sEAQQZAW3qFOSYSjBuPoLEsT6dCTmCgU9MhyATAQ6ZjhxDaNUxFkGC6mBmD0t60DldPpBz5igIGUEKwtwUCjkCIDulQBAnsFthkcMZsHN4BHEEbGbHJD3kmOL0uZ/bKj/CCOLE1swekPSIU/itsO/lf8Xlcw4/ygjiwDZQjiMppeccLoGQHQEEKdwKyFEY6MzhEKRgAZCjIMxKQiFIoUKY2X2SHisUblOYfObgtsoZ8vbwCFIANnIUgFhpCASZWBjkmAiw8ukIMqFAyDEBXiNTEWRkoczsHklPjJzedxpnjr6knMYhyAiwQXK8K+lWPucYUaCCUxBkIMxAOW5KKT0/cHkML0wAQQYARY4BsBYyFEF6FhI5eoJa2DAE6VFQM7tT0tM9hk4Zks8c3FZNIegwF0H2gdrJkZ/R4ckKORyau0RIz6KXWN+sMZBjVvxVJEeQDWVAjir6c/ZFIMguJTCz2yXl5wJ68uG2avb2338Bng2wf/YKR3Ry5CcuHXBc3juSbuZzDkfChUIjyDaQgXJcl1J6sVANCeNIAEE6uMjh2GUNh0aQ//4c6C2STgTcVrFzNCbL6gXp5Mi/fn7QsXb5zIEcjoC9Qq9aEOTwaqvlxF2tIMixnCb2vJJVCoIcni21rNirE8TMbpB00vnM8bak63krt31ZViWImV0t6ZRz2f4t6WsppR875yF8AIG1CXKOpJ9J+qwT27xzXJNSetkpPmGDCaxKkMzWzM7rJPl0YdbIURhoDeFWJ0gnyfmSfi7pU4WKgByFQNYWZpWCdJJcIOlVSZdOLApyTARY8/TVCtJJcpGkX0r6xMgiIcdIcK1MW7UgnSQXdzvJRwcWDTkGAmtx+OoF6SS5pJPkwp5FRI6eoFofhiBdBc3ssu7g/uF9ivqWpGt5K7f11u+3fgTZxsnMLu92kg9twJflOJxSeq0fXka1TgBBdlTQzA5Jyp+Cf3DHn5Cj9W4fsX4E2QWamV0p6QVJH+j+jBwjmmsJUxBkQxXN7LCk/OPR+REE3FYtodtHXAOC7AHNzG6U9I+U0isj2DJlAQQQZAFF5BL8CCCIH1siL4AAgiygiFyCHwEE8WNL5AUQQJAFFJFL8COAIH5sibwAAgiygCJyCX4EEMSPLZEXQABBFlBELsGPAIL4sSXyAgggyAKKyCX4EUAQP7ZEXgABBFlAEbkEPwII4seWyAsg8B8Vzez2xcX9vgAAAABJRU5ErkJggg==');
    background-size:0.9rem;
    background-position:center;
    background-repeat:no-repeat;
  }
</style>
