import Vue from 'vue'
import Router from 'vue-router'
import Home from './views/Home.vue'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'home',
      component: Home
    },
    {
      path: '/login',
      name: 'login',
      component: () => import('./views/Login.vue')
    },

    {
      path: '/registor',
      name: 'registor',
      component: () => import('./views/Registor.vue')
    },
    {
      path: '/resetpass',
      name: 'resetpass',
      component: () => import('./views/Resetpass.vue')
    },
    {
      path: '/loginpass',
      name: 'loginpass',
      component: () => import('./views/Loginpass.vue')
    },
    {
      path: '/dealpass',
      name: 'dealpass',
      component: () => import('./views/Dealpass.vue')
    },
    {
      path: '/protocol',
      name: 'protocol',
      component: () => import('./views/Protocol.vue')
    },
    {
      path: '/helpcenter',
      name: 'helpcenter',
      component: () => import('./views/Helpcenter.vue')
    },
    {
      path: '/helpdetail',
      name: 'helpdetail',
      component: () => import('./views/HelpDetail.vue')
    },
    {
      path: '/safety',
      name: 'safety',
      component: () => import('./views/Safety.vue')
    },
    {
      path: '/setting',
      name: 'setting',
      component: () => import('./views/Setting.vue')
    },
    {
      path: '/friend',
      name: 'friend',
      component: () => import('./views/Friend.vue')
    },

    {
      path: '/generalize',
      name: 'generalize',
      component: () => import('./views/Generalize.vue')
    },
    {
      path: '/about',
      name: 'about',
      // route level code-splitting
      // this generates a separate chunk (about.[hash].js) for this route
      // which is lazy-loaded when the route is visited.
      component: () => import(/* webpackChunkName: "about" */ './views/About.vue')
    }
  ]
})
