<template>
  <form class="unfreeze">
    <transition name="opaci" type="animation">
      <div :class="'u-out'+(show?' tran':'')" @click.stop="_control" v-show="show"></div>
    </transition>
    <transition  name="drop" type="animation">
      <div :class="'u-in'+(show?' tran':' tran-leave')" v-show="show" @click.stop="_control" >
        <div class="u-in-form" @click.stop="">
          <p class="ui-topic">解冻账户</p>
          <div class="ui-body">
            <div class="ub-flex">

              <div class="uf-text uf-col">需支付</div>
              <div class="uf-number uf-col">
                {{msg}} PDC
              </div>
            </div>
          </div>
          <div class="ui-footer">
            <div class="uf-btn ub-pay">支付</div>
          </div>
          <p class="ui-title">冻结期间，账户无法正常使用</p>
        </div>
      </div>
    </transition>
  </form>
</template>

<script>
  export default {
    name: 'Unfreeze',
    props: {
      msg: Number,
      show:Boolean
    },
    methods:{
      /* 控制弹窗的关闭*/
      _control(){

        this.$emit('controlfn',{show:!this.show})
      }

    }
  }
</script>
<style>
  body,html{font-size:unset !important;}

</style>
<style scoped>
  /*动画效果*/
  .u-out.tran{
    animation:uout 0.5s;
  }

  @keyframes uout{
    0%{
      display:none;
      opacity:0;
    }
    100%{
      display:block;
      opacity:1;
    }
  }

  @keyframes uin{
    0%{
      transform:scale(0) rotateZ(10deg);

    }
    20%{
      transform:scale(0.2) rotateZ(0deg)
    }
    40%{
      transform:scale(0.4) rotateZ(-10deg)
    }
    60%{
      transform:scale(0.6) rotateZ(0deg)
    }
    80%{
      transform:scale(0.8) rotateZ(10deg)
    }
    100%{
      transform:scale(1) rotateZ(0)
    }
  }
  @keyframes uin-leave{
    100%{
      transform:scale(0) rotateZ(10deg);

    }
    80%{
      transform:scale(0.2) rotateZ(0deg)
    }
    60%{
      transform:scale(0.4) rotateZ(-10deg)
    }
    40%{
      transform:scale(0.6) rotateZ(0deg)
    }
    20%{
      transform:scale(0.8) rotateZ(10deg)
    }
    0%{
      transform:scale(1) rotateZ(0)
    }
  }
  .u-in.tran{
    animation:uin .5s;
  }
  .u-in.tran-leave{
    animation:uin-leave .5s;
  }
  .ui-topic{
    padding-top:1rem;
    text-align:center;
    font-size:1.2rem;
    color:#fff;
    margin:0;
  }
  .uf-number{
    text-align:right;
  }
  .ub-flex{
    display:flex;
    align-items:center;
    font-size:1rem;
    padding:1rem 0;
    text-align:left;
  }
  .uf-col{
    flex:1;
    color:#fff;
  }
  .ui-footer{
    display:flex;
  }
  .uf-btn{
    flex:1;
    height: 2rem;
    background-color: #1c213e;
    border-radius: 0.2rem;
    border: solid 1px #393e6b;
    font-family: PingFangSC-Regular;
    font-size: 0.8rem;
    font-weight: normal;
    font-stretch: normal;
    line-height: 2rem;
    letter-spacing: 0rem;
    padding:0 1rem;
    text-align:center;
    transition:all .5s;
    user-select:none;
    outline:none;
  }
  .ub-pay{
    background-color:#4075f5;

    background-blend-mode: normal,
    normal;
    border-radius: 0.2rem;
    border: solid 0rem #345cca;
    color:#fff;

  }

  .ub-pay:active{
    background-color:transparent;
    opacity: 0.7;

  }
  .u-in{
    z-index:1000;
    position:fixed;
    top:0;
    right:0;
    left:0;
    bottom:0;
    margin:auto;
    width:80%;
    display:flex;
    align-items:center;
    justify-content: center;
  }
  .ui-title{
    font-size:0.8rem;
    color:#3666bd;
    text-align:center;
  }
  .u-in-form{
    width:100%;
    border-radius:5px;
    background-color:#141732;
    border:1px solid #393e6b;
    padding:0 1rem 1rem 1rem;
  }
  .u-out{
    z-index:999;
    position:fixed;
    top:0;
    right:0;
    bottom:0;
    left:0;
    width:100%;
    height:100%;
    background-color:rgba(255,255,255,0.3);
  }
</style>
